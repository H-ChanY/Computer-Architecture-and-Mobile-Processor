#include "mips.h"

int Memory[0x400000]={0};           //16MB memory
int reg[32]={0};
int pc=0;
