#include "mips.h"

extern int Memory[0x400000];       //16MB memory
extern int reg[32];
extern int pc;
extern BTB btb_[100];
extern int num_br;

void branch_pc(IF_ID *if_id,ID_EX* id_ex,ID_EX* id_ex1 ,EX_MEM * ex_mem){
    // 첫 시작 
    int index=0;
    int chk=0;    
        if(id_ex->opcode==bne||id_ex->opcode==beq){
            for(int k=0; k<=num_br;k++){
                // 현재 pc가 branch_pc에 있는가 확인해야함. 
                if(btb_[k].branch_pc==ex_mem->pc_4-4){
                    chk=1;
                    index=k;
                    break;
                }
            }
            if(chk==0){
                btb_[num_br].branch_pc=ex_mem->pc_4-4;
                btb_[num_br].Target=ex_mem->branch_addr;
                if(ex_mem->zero_){
                    btb_[num_br].prediciton_bit=1;
                    pc=ex_mem->branch_addr;
                    memset(if_id,false,sizeof(IF_ID));
                    memset(id_ex1,false,sizeof(ID_EX));
                }else{
                    btb_[num_br].prediciton_bit=0;
                    pc=id_ex->pc_4;
                }    
                
                num_br+=1;
            }
        }
    
    

    // branch prediction 의 성공 여부에 대해서 확인을 해야함. 
    // 어디로 갔는지 그러면 bit를 확인해야함. 
    if(chk!=0&&ex_mem->zero_&& ex_mem->Br_taken && btb_[index].prediciton_bit==1){
            //branch 성공한 경우 그냥 놔두면 됨 어차피 예측 성공이니까.
            num_success+=1;
    }else if(chk!=0&&!ex_mem->zero_&& ex_mem->Br_taken && btb_[index].prediciton_bit==1){
        //predict 실패 
        btb_[index].prediciton_bit=0;
        pc=btb_[index].branch_pc+4;
        num_not_branch+=1;
        memset(if_id,false,sizeof(IF_ID));
        memset(id_ex1,false,sizeof(ID_EX));    
        num_fail+=1; 
    }
    else if(chk!=0&&!ex_mem->zero_&& ex_mem->Br_taken && btb_[index].prediciton_bit==0){
        // br not taken 정답
        num_not_branch+=1;
        num_success+=1;
    }
    else if(chk!=0&&ex_mem->zero_&& ex_mem->Br_taken && btb_[index].prediciton_bit==0){
        //branch 가야하고 예측 실패
        btb_[index].prediciton_bit=1;
    
        num_fail+=1;
        pc=btb_[index].Target;
        memset(if_id,false,sizeof(IF_ID));
        memset(id_ex1,false,sizeof(ID_EX));           
    }
    
    
    
}